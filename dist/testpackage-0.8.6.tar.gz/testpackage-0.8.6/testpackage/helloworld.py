class helloworld:
  def __init__(self):
    pass
  def hi(self):
    print('hieii')
if __name__ == "__main__":
  helloworld().hi()
